﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H2O_odf
{
    class Font
    {
        public string addFont()
        {
            List<string> font = new List<string>();
            font.Add("궁서");
            string str = "";
            for(int i = 0; i < font.Count; i++)
            {
                str = str + "<style:font-face style:name=\"" + font[i] + "\" svg:font-family=\"" + font[i] + "\" style:font-family-generic=\"modern\" style:font-pitch=\"variable\"/>";
            }
            return str;
        }
    }
}
