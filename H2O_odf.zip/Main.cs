﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H2O_odf
{
    class MainClass
    {
        static void Main(string[] args)
        {
            OdfManager odf = new OdfManager();
            odf.makeOdf();
        }
    }
}
